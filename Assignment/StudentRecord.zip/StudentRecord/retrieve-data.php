<?php


include 'connection.php';

$query5= "SELECT * FROM semesterdetails  WHERE EnrollmentNo = 'enroll' "; // Fetch all the data from the table customers

$result=mysqli_query($conn,$query5);

?>