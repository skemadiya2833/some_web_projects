<?php include("connection.php") ?>
<?php 
 $all = " SELECT * FROM studentdetails INNER JOIN semesterdetails ON studentdetails.EnrollmentNo = semesterdetails.EnrollmentNo ORDER BY 'StudentName' ASC";

 $alldata = mysqli_query($conn, $all);

//  $totalrow = mysqli_num_rows($alldata);
$html ='<table><tr><td>Image</td><td>Enrollment</td><td>Name</td><td>College</td><td>Course</td><td>Branch</td><td>Semester</td><td>Session</td><td>Bus</td><td>DoB</td><td>Admission Under</td><td>Category</td><td>Phone No</td><td>Aadhar No</td><td>Mail id</td><td>Father Name</td><td>Father PhoneNo</td><td>Residency</td><td>Living</td><td>Locality</td><td>City</td><td>State</td><td>Pincode</td><td>Local Address</td><td>Guardian Name</td><td>Guardian ContactNo</td><td>Semester No</td><td>Result</td><td>CGPA</td><td>Backlogs</td>';
while ($finalresult = mysqli_fetch_assoc($alldata))
{
    $html.='<tr><td>'. $finalresult['StudentImage'] .'</td><td>'. $finalresult['EnrollmentNo'] .'</td><td>'. $finalresult['StudentName'] .'</td><td>'. $finalresult['CollegeName'] .'</td><td>'. $finalresult['CourseName'] .'</td><td>'. $finalresult['Branch'] .'</td><td>'. $finalresult['Semester'] .'</td><td>'. $finalresult['Academic'] .'</td><td>'. $finalresult['Bus'] .'</td><td>'. $finalresult['DateOfBirth'] .'</td><td>'. $finalresult['AdmissionUnder'] .'</td><td>'. $finalresult['Category'] .'</td><td>'. $finalresult['Phoneno'] .'</td><td>'. $finalresult['Aadharno'] .'</td><td>'. $finalresult['Mailid'] .'</td><td>'. $finalresult['FatherName'] .'</td><td>'. $finalresult['FatherPhoneNo'] .'</td><td>'. $finalresult['Residency'] .'</td><td>'. $finalresult['Living'] .'</td><td>'. $finalresult['Locality'] .'</td><td>'. $finalresult['City'] .'</td><td>'. $finalresult['HomeState'] .'</td><td>'. $finalresult['Pincode'] .'</td><td>'. $finalresult['LocalAddress'] .'</td><td>'. $finalresult['GuardianName'] .'</td><td>'. $finalresult['GuardianContactNo'] .'</td><td>'. $finalresult['SemesterNo'] .'</td><td>'. $finalresult['Result'] .'</td><td>'. $finalresult['CGPA'] .'</td><td>'. $finalresult['Backlogs'] .'</td>';
}
$html.='</table>';
header('Content-Type:application/xls');
header('Content-Disposition:attachment;filename=student_data.xls');
echo $html;
?>
