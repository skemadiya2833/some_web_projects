<?php include("connection.php") ?>
<?php
session_start();
echo "Welcome " . $_SESSION['user_name'];
$userprofile = $_SESSION['user_name'];

if ($userprofile == true) 
{
} 
else {
?>
    <meta http-equiv="refresh" content="0; url = loginpage.php" />
<?php
}
?>
<html>

<head>
    <title>Print Page</title>
    <link rel="stylesheet" type="text/css" href="pdfpage.css">

</head>

<body>
    <div class="btn-block1">
        <a href="logout.php"><input type="btn" value="Log Out" class="btn" name="logout"></a>
    </div>
    <?php
    $querry3 = "SELECT * FROM studentdetails WHERE Mailid = '$userprofile'";
    $data3 = mysqli_query($conn, $querry3);

    if (mysqli_num_rows($data3) > 0) 
    {
        foreach($data3 as $row)
        {
        ?>
            <div class="main-page" id="main-page">
            <div class="sub-page">
                <div class="banner">
                    <img src="logo.jpeg" height="200px" width="720px" margin-top="auto" margin-right="auto" justify-content="center" align-items="center" display="flex" background-size="cover" alt="Your Image">
                    <!-- <h1 align='center'>Sushila Devi Bansal College</h1> -->
                </div>
                <h4 align='center'>Umaria, A.B. Road, Rau, INDORE-453 331 (M.P.)</h4>

                Date of Registration: <input type="text" value=<?php echo $row['RegistrationDate']; ?>>
                <h2 align='center'>Registration Form</h2>

                <img src="student_images/<?php echo $row['StudentImage']; ?>" width="100px" height="100px" align="right">
                <ul class="cards" type="1">
                    <li>Application for Registration for the session:<input type="text" size=10 readonly="true" value=<?php echo $row['Academic']; ?>> </li>

                    <li>Course <input type="text" size=10 readonly="true" value=<?php echo $row['CourseName']; ?>>
                        Branch <input type=text size="50" readonly="true" value="<?php echo $row['Branch']; ?>"></li>

                    <li>Semester <input type="text" readonly="true" value="<?php echo $row['Semester']; ?>"> Commencing w.e.f.<input type="text" readonly="true"></li>

                    <li>University Enrollment No. <input type="text" readonly="true" value=<?php echo $row['EnrollmentNo']; ?>>
                        <br>
                        <h3 align='left'>Personal Particulars:</h3>
                        <ul class="cards" type="1">
                            <li>Name: <input type="text" readonly="true" value="<?php echo $row['StudentName']; ?>"> S/o.D/o. <input type="text" readonly="true" value="<?php echo $row['FatherName']; ?>"></li>
                            <li>Date of Birth:<input type="text" readonly="true" value=<?php echo $row['DateOfBirth']; ?>> Aadhar No. <input type="text" readonly="true" value=<?php echo $row['StudentName']; ?>></li>
                            <li>Contact No. <input type="text" readonly="true" value=<?php echo $row['Phoneno']; ?>> Father Contact No. <input type="text" readonly="true" value="<?php echo $row['FatherPhoneNo']; ?>"></li>
                            <li>Mail: <input type="text" size=30 readonly="true" value=<?php echo $row['Mailid']; ?>> Category: <input type="text" readonly="true" value=<?php echo $row['Category']; ?>>
                            <li>Admission Under: <input type="text" readonly="true" value="<?php echo $row['AdmissionUnder']; ?>"></li>
                            <li>Residency: <input type="text" readonly="true" value="<?php echo $row['Residency']; ?>"> Living: <input type="text" readonly="true" value="<?php echo $row['Living']; ?>"></li>
                            <li>Local Address: <input type="text" size=50 readonly="true" value="<?php echo $row['LocalAddress']; ?>"></li>
                            <li>Locality: <input type="text" readonly="true" value="<?php echo $row['Locality']; ?>"></li>
                            <li>City:<input type="text" readonly="true" value="<?php echo $row['City']; ?>"> State: <input type="text" readonly="true" value="<?php echo $row['HomeState']; ?>"> Pincode: <input type="text" readonly="true" value="<?php echo $row['Pincode']; ?>"></li>
                            <li>Guardian Name: <input type="text" readonly="true" value="<?php echo $row['GuardianName']; ?>"> Guardian Contact No. <input type="text" readonly="true" value=<?php echo $row['GuardianContactNo']; ?>>
                        </ul>
                        <br>
                        <h3 align='left'>Examination Results:</h3>

                        <table style="width:100%">

                            <tr>
                                <th style="width:70%">Semester</th>
                                <th>Result-Pass/Fail/Awaited</th>
                                <th>SGPA</th>
                                <th>Backlogs</th>
                            </tr>
                            <?php
                            $querynew = "SELECT * FROM semesterdetails INNER JOIN studentdetails on semesterdetails.EnrollmentNo = studentdetails.EnrollmentNo where studentdetails.Mailid = '$userprofile'";
                            $newresult = mysqli_query($conn, $querynew);
                            // echo mysqli_num_rows($newresult);
                            while ($row1 = mysqli_fetch_assoc($newresult)) {
                            ?>
                                <tr>
                                    <td><input type="text" readonly="true" value="<?php echo $row1['SemesterNo']; ?>"></td>
                                    <td><input type="text" readonly="true" value="<?php echo $row1['Result']; ?>"></td>
                                    <td><input type="text" readonly="true" value="<?php echo $row1['CGPA']; ?>"></td>
                                    <td><input type="text" readonly="true" value="<?php echo $row1['Backlogs']; ?>"></td>


                                </tr>

                            <?php }
                            ?>
                        </table>

                        <br>
                        Signature of the student: <br>
                        <br>
                        <br>
                        
            </div>
            
            <div class="sub-page2">
                
                <h1 align='center'>Undertaking</h1>
                <h4>I <input type="text" readonly="true" value="<?php echo $row['StudentName']; ?>"> S/o./D/o. Mr. <input type="text" readonly="true" value="<?php echo $row['FatherName']; ?>"> Resident of <input type="text" readonly="true" value="<?php echo $row['City']; ?>"> and student of MBA/MCA/B.TECH
                    <input type="text" readonly="true" size="30"value="<?php echo $row['Branch']; ?>"> Branch.)
                </h4>
                <ol>
                    <li>I fully understand that ragging in any form is a punishable offence and is banned by Honorable Supreme Court of India and Government of M.P.</li>

                    <li>I shall not directly or indirectly involve in ragging or any other unlawful activity activity inside or outside of the college campus during my entire period of studies at the collge.</li>

                    <li>If i am found involved in any such act of ragging, as defined in Pariniyam 38A of M.P Vishwavidhyalaya Adhiniyam 1973, necessary disciplinary action, including filing of FIR with police, may be initiated against me. I am aware of and also fully understand the con consequenses of any such act of ragging, which may include suspension form clasess, debarring form university examination, rustication from the college or any other action(s) as deemed appropriate by the management of the college.</li>
                    <li>I shall abide by the General code of Conduct for the students and shall not involve in any activity of indiscipline during my studies at this college</li>
                    <li>I shall attend all the classes regularly and punctually I am fully aware that,if my attendence in any subject (theory/practicle) fails below 75% in the semester my Examination form will not be forwarded to the University.</li>
                    <li>In the event of withdrawal / Cancellation of my addmission for any reason whatever,at any time during the entire period of my course,I shall be liable to pay the complete fee due to me and that in such case i shall not claim refund of fee of any kind, at any time after withdrawl/cancellation of my admission.</li>
                </ol>
                <br>
                Signature of the Student:
                <br><br>
                <br>
                        Signature of the Parent:
                <br>
            </div>
          </div>
        <?php
        }
    }
    else
    {
        echo "No record found.";
    }
    ?>
    <div class="printbtnbox">
        <input type='button' id='btn' class="printbtn" value='Print' onclick='window.print()'>
    </div>

    <script>
        function printDiv() {

            // var divToPrint = document.getElementById('main-page');

            // var newWin = window.open('', 'Print-Window');

            // newWin.document.open();

            // newWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</body></html>');

            // newWin.document.close();

            setTimeout(function() {
                newWin.close();
            }, 10);

        }
    </script>
</body>

</html>