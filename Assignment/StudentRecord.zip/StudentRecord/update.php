<?php include("connection.php"); 
$selectedenroll= $_GET['EnrollmentNo'];
// $all = " SELECT * FROM studentdetails INNER JOIN semesterdetails ON studentdetails.EnrollmentNo = semesterdetails.EnrollmentNo ORDER BY 'StudentName' ASC WHERE 'EnrollmentNo'='$selectedenroll'";
$all = " SELECT * FROM studentdetails WHERE 'EnrollmentNo'='$selectedenroll'";

    $alldata = mysqli_query($conn, $all);

    $totalrow = mysqli_num_rows($alldata);
    $finalresult = mysqli_fetch_assoc($alldata);
?>



<!DOCTYPE html>
<html>

<head>
    <title>Registration Form</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style1.css">
    <script src="constraints.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<script>
    function get_enroll(id1) {
        var enrollment_id = document.getElementById(id1);
        enrollment_number = enrollment_id.value;

        console.log(enrollment_number);
    }
</script>

<body>

    <div class="testbox">
        <form action="#" method="POST" enctype="multipart/form-data">
            <div class="banner">
            </div>
            <h2>Update Form</h2>
            <div class="column">
                <div class="item">
                    <label for="enroll">Enrollment No<span>*</span></label>
                    <input id="enroll" value="<?= $row['EnrollmentNo']; ?>" type="text" name="studentenrollment" required />
                </div>

                <div class="item">
                    <label for="enroll">Upload Your Image</label>
                    <input type="file" name="uploadfile" class='imagebox' accept="image/png, image/jpg, image/jpeg">
                </div>
            </div>
            <!-- <div>
                <button id="enroll-btn" name="enroll-btn" onclick="get_enroll('enroll')"> Get data</button>
            </div> -->
            <!-- <div class="btn-block">
                <input type="submit" value="GetData" class="btn" name="getdata">
            </div> -->
            <?php

            // if (isset($_POST['getdata'])) 
            // {
            //     $studentenrollment2   = $_POST['studentenrollment'];

            //     $querry4 = "SELECT * FROM studentdetails WHERE EnrollmentNo = '$studentenrollment2'";
            //     $data4 = mysqli_query($conn, $querry4);
            //     if (mysqli_num_rows($data4) > 0) 
            //     {
            //         foreach($data4 as $row)
            //         {
            //             echo $row['StudentName'];
            //             
            ?>

            <?php
                //         }
                //     }
                //     else
                //     {
                //         echo "No Record Found";
                //     }

                // }

                ?>
            <div class="column">
                <div class="item">
                    <label for="name">Name<span>*</span></label>
                    <input id="name" value="<?= $row['StudentName']; ?>" type="text" name="studentname" required />
                </div>
            </div>
            <!-- <div>
                <button id="enroll-btn" onclick="get_enroll('enroll')"> getdata</button>
            </div> -->

            <div class="column">
                <div class="item">
                    <label for="college">College<span>*</span></label>
                    <select name="collegename" class="collegebox" id="collegename" onchange="populateProfession('profession','branch','collegename')" required>
                        <option selected value="" disabled selected></option>
                        <option value="SDBCE">Sushila Devi Bansal College of Engineering</option>
                        <option value="SDBCT">Sushila Devi Bansal College of Technology</option>
                    </select>
                </div>
                <div class="item">
                    <label for="course">Course<span>*</span></label>
                    <select name="coursename" class="coursebox" id="profession" required onchange="populateProfession('profession','branch','collegename')">
                        <option selected value="" disabled selected></option>
                        <option value="B.TECH">B.TECH</option>
                        <option value="M.TECH/M.E">M.TECH/M.E</option>
                        <option value="MBA">MBA</option>
                    </select>
                </div>
            </div>


            <div class="column">
                <div class="item">
                    <label for="branch">Branch<span>*</span></label>
                    <select name="branch" class="branchbox" id="branch" required>

                    </select>
                </div>
                <div class="item">
                    <label for="semester">Semester<span>*</span></label>
                    <select name="semester" class="semesterbox" id="semester" required onchange="populateYear(this.id,'year')">
                        <option selected value="" disabled selected></option>
                        <option value="1st Semester">1st Semester</option>
                        <option value="2nd Semester">2nd Semester</option>
                        <option value="3rd Semester">3rd Semester</option>
                        <option value="4th Semester">4th Semester</option>
                        <option value="5th Semester">5th Semester</option>
                        <option value="6th Semester">6th Semester</option>
                        <option value="7th Semester">7th Semester</option>
                        <option value="8th Semester">8th Semester</option>
                    </select>
                    <select name="year" id="year"></select>
                </div>
            </div>

            <div class="column">
                <div class="item">
                    <label for="session">Session<span>*</span></label>
                    <select name="session" class="sessionbox" required>
                        <option selected value="" disabled selected></option>
                        <option value="Jan-Jun">Jan - Jun</option>
                        <option value="July-Dec">July - Dec</option>
                    </select>
                </div>
                <div class="item">
                    <label for="bus">Bus Facility Availed<span>*</span></label>
                    <select name="bus" class="busbox" required>
                        <option selected value="" disabled selected></option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>

            <div class="addressbox">
                <div class="item">
                    <label for="bdate">Date of Birth<span>*</span></label>
                    <input id="bdate" type="date" required name="dateofbirth" />
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <div class="item">
                    <label for="admissionunder">Admission Under<span>*</span></label>
                    <select name="admissionunder" class="admissionunderbox" required>
                        <option selected value="" disabled selected></option>
                        <option value="TFW">TFW</option>
                        <option value="EWS">EWS</option>
                        <option value="UR">UR</option>
                    </select>
                </div>
                <div class="item">
                    <label for="category">Category<span>*</span></label>
                    <select name="category" id="category" class="categorybox" required>
                        <option selected value="" disabled></option>
                        <option value="General">General</option>
                        <option value="OBC">OBC</option>
                        <option value="ST">ST</option>
                        <option value="SC">SC</option>
                    </select>
                </div>
            </div>



            <div class="column">
                <div class="item">
                    <label for="phone">Phone<span>*</span></label>
                    <input id="phone" placeholder="Enter 10 digit contact no." type="number" name="phoneno" min="1000000000" max="9999999999" required oninvalid="this.setCustomValidity('please enter 10 digit moblie number')" oninput="setCustomValidity('')" />

                </div>
                <div class="item">
                    <label for="aadharno">Aadhar No.<span>*</span></label>
                    <input id="aadharno" placeholder="Enter 12 digit Aadhar no." type="number" name="aadharno" required oninvalid="this.setCustomValidity('please enter 12 digit Aadhar.no number')" oninput="setCustomValidity('')" />
                </div>
            </div>



            <div class="item">
                <label for="mailid">Mail id<span>*</span></label>
                <input id="mailid" placeholder="Use official mail id -  eg. xyz@sdbc.ac.in" type="mail" name="mailid" required />
            </div>


            <div class="column">
                <div class="item">
                    <label for="fathername">Father Name<span>*</span></label>
                    <input id="fathername" type="text" placeholder="Mr." name="fathername" required />
                </div>
                <div class="item">
                    <label for="fathercontactno">Father Contact No.<span>*</span></label>
                    <input id="fathercontactno" placeholder="Enter 10 digit contact no." class="number" type="number" name="fathercontactno" required min="1000000000" max="9999999999" oninvalid="this.setCustomValidity('please enter 10 digit moblie number')" oninput="setCustomValidity('')" />
                    <!-- changed style -webkit-inner-spin-button = none  -->
                </div>
            </div>



            <div class="column">
                <div class="question">
                    <label>Residency</label>
                    <div class="question-answer">

                        <div>
                            <input type="radio" value="Localite" id="radio_6" name="residency" id="localite" onclick="living(0)" onclick="undertaking()" />
                            <label for="radio_6" class="radio"><span>Localite</span></label>
                        </div>

                        <div>
                            <input type="radio" value="Non-Localite" id="radio_7" name="residency" id="Non-Localite" onclick="living(1)" />
                            <label for="radio_7" class="radio"><span>Non-Localite</span></label>
                        </div>
                    </div>
                </div>


                <div class="item">
                    <p id="living">Living</p>
                    <select name="student_living" id="livingOptions" class="livingbox">
                        <option selected value="" disabled></option>
                        <option value="Hostel">Hostel</option>
                        <option value="House on Rent">House on Rent</option>
                        <option value="With Relatives">With Relatives</option>
                        <option value="With Local Guardian">With Local Guardian</option>
                    </select>
                </div>
            </div>


            <div class="item">
                <label for="locality">Locality<span>*</span></label>
                <input id="locality" type="text" name="locality" required />
            </div>
            <div class="addressbox">
                <div class="item">
                    <label for="city">City<span>*</span></label>
                    <input id="city" type="text" name="city" required />
                </div>
                <div class="item">
                    <label for="state">State<span>*</span></label>
                    <input id="state" type="text" name="state" required />
                </div>

                <div class="item">
                    <label for="pincode">Pincode<span>*</span></label>
                    <input id="pincode" type="number" name="pincode" required />
                </div>
            </div>


            <div class="item">
                <label for="localaddress" id="localaddress-span">Local Address</label>
                <input id="localaddress" type="text" name="localaddress" />
            </div>

            <div class="column">
                <div class="item">
                    <label for="guardianname">Guardian Name<span>*</span></label>
                    <input id="guardianname" type="text" name="guardianname" required />
                </div>
                <div class="item">
                    <label for="gurdiancontactno">Gurdian Contact No.<span>*</span></label>
                    <input id="gurdiancontactno" type="number" name="guardiancontactno" min="1000000000" max="9999999999" required oninvalid="this.setCustomValidity('please enter 10 digit moblie number')" oninput="setCustomValidity('')" />
                </div>
            </div>


            <div class="item">
                <label>Examination Results:</label>
            </div>
            <table class="table">
                <thead>

                    <tr>
                        <th>Sem</th>
                        <th>Result:- Pass/ Fail/ Awaited</th>
                        <th>SGPA</th>
                        <th>Backlog</th>
                    </tr>

                    <?php include("retrieve-data.php"); ?>
                    <?php if ($result->num_rows > 0) : ?>
                        <?php while ($array = mysqli_fetch_row($result)) : ?>
                            <tr>
                                <th scope="row"><?php echo $array[2]; ?></th>
                                <td><?php echo $array[3]; ?></td>
                                <td><?php echo $array[4]; ?></td>
                                <td><?php echo $array[5]; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="3" rowspan="1" headers=""></td>
                        </tr>
                    <?php endif; ?>
                    <?php mysqli_free_result($result); ?>


                    <!-- <tr>
                        <td>
                            <select name="semesterD" class="semesterbox" id="semester-t">
                                <option selected value="" disabled selected></option>

                            </select>
                        </td>
                        <th>
                            <select name="semResult" class="semesterbox" id="semester-d"onchange="disable('semResult')">
                                <option value="" disabled selected></option>
                                <option value="PASS">PASS</option>
                                <option value="FAIL">FAIL</option>
                                <option value="AWAITED">AWAITED</option>
                            </select>
                        </th>
                        <th><input type="float" name="semCGPA" id="semCGPA"></th>
                        <th><input type="string" name="semSubject" id="subjectcarried"></th>
                    </tr> -->
                    <tr>
                        <td>
                            <select name="semesterD" class="semesterbox" id="semester-t">
                                <option selected value="" disabled selected></option>

                            </select>
                        </td>
                        <th><select name="semresult" id="result" onchange="disable('result')">
                                <option selected value="" disabled selected></option>
                                <option value="pass">PASS</option>
                                <option value="fail">FAIL</option>
                                <option value="awaited">AWAITED</option>

                            </select></th>
                        <th><input type="number" name="semCGPA" id="semCGPA" min="0.00" max="10.00" step="0.01"></th>
                        <th><input type="string" name="subjectcarried" id="subjectcarried"></th>
                    </tr>
            </table>

            <!-- <div>
                <button id="enroll-btn" onclick="get_enroll('enroll')">Submit Semester data</button>
            </div> -->

            <div class="term_checkbox">
                <input id="checkbox" type="checkbox" onclick="undertaking(1)" onchange="undertaking_data()" />
                <label for="checkbox">&emsp;I've filled all the informations carefully, read the undertaking below & accept it.</label>
            </div>

            <div id="undertaking">
                <h2>Undertaking</h2>
                <h4>I <input type="text" id="under-name"> S/o./D/o. Mr. <input type="text" id="under-father"> Resident of <input type="text" id="under-address">and student of MBA/MCA/B.TECH
                    (<input type="text" id="under-branch">Branch.)</h4>
                <ol>
                    <li>I fully understand that ragging in any form is a punishable offence and is banned by Honorable Supreme Court of India and Government of M.P.</li>

                    <li>I shall not directly or indirectly involve in ragging or any other unlawful activity activity inside or outside of the college campus during my entire period of studies at the collge.</li>

                    <li>If i am found involved in any such act of ragging, as defined in Pariniyam 38A of M.P Vishwavidhyalaya Adhiniyam 1973, necessary disciplinary action, including filing of FIR with police, may be initiated against me. I am aware of and also fully understand the con consequenses of any such act of ragging, which may include suspension form clasess, debarring form university examination, rustication from the college or any other action(s) as deemed appropriate by the management of the college.</li>
                    <li>I shall abide by the General code of Conduct for the students and shall not involve in any activity of indiscipline during my studies at this college</li>
                    <li>I shall attend all the classes regularly and punctually I am fully aware that,if my attendence in any subject (theory/practicle) fails below 75% in the semester my Examination form will not be forwarded to the University.</li>
                    <li>In the event of withdrawal / Cancellation of my addmission for any reason whatever,at any time during the entire period of my course,I shall be liable to pay the complete fee due to me and that in such case i shall not claim refund of fee of any kind, at any time after withdrawl/cancellation of my admission.</li>
                </ol>
            </div>

            <!-- <div class="term_checkbox"> -->
            <!-- <input id="checkbox2" type="checkbox"/> -->
            <!-- <label for="checkbox2">Yes I've read the undertaking carefully.</label> -->
            <!-- </div> -->
            <br><br>
            <div class="btn-block">
                <span>Already registered. </span>
                <a href="loginpage.php" class="txt2">
                    Login
                </a>
            </div>
            <div class="btn-block">
                <input type="submit" value="Update" class="btn" name="submit">
            </div>

        </form>
    </div>
</body>

</html>
<?php

if (isset($_POST['submit'])) {
    error_reporting(0);


    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];
    $folder = "student_images/" . $filename;
    move_uploaded_file($tempname, $folder);

    $studentenrollment   = $_POST['studentenrollment'];
    $studentname         = $_POST['studentname'];
    $collegename         = $_POST['collegename'];
    $coursename          = $_POST['coursename'];
    $branch              = $_POST['branch'];
    $semester            = $_POST['semester'];
    $academicsession     = $_POST['session'];
    $bus                 = $_POST['bus'];
    $dateofbirth         = $_POST['dateofbirth'];
    $admissionunder      = $_POST['admissionunder'];
    $category            = $_POST['category'];
    $phoneno             = $_POST['phoneno'];
    $aadharno            = $_POST['aadharno'];
    $mailid              = $_POST['mailid'];
    $fathername          = $_POST['fathername'];
    $fathercontactno     = $_POST['fathercontactno'];
    $residency           = $_POST['residency'];
    $studentliving       = $_POST['student_living'];
    $locality            = $_POST['locality'];
    $city                = $_POST['city'];
    $state               = $_POST['state'];
    $pincode             = $_POST['pincode'];
    $localaddress        = $_POST['localaddress'];
    $guardianname        = $_POST['guardianname'];
    $guardiancontactno   = $_POST['guardiancontactno'];
    $semesterD        = $_POST['semesterD'];
    $semResult        = $_POST['semresult'];
    $semSGPA          = $_POST['semCGPA'];
    $backlogSubject   = $_POST['subjectcarried'];




    $querry1 = "SELECT * FROM studentdetails WHERE EnrollmentNo = '$studentenrollment'";
    $semdata1 = mysqli_query($conn, $querry1);
    $total1 = mysqli_num_rows($semdata1);

    $querry2 = "SELECT * FROM semesterdetails WHERE EnrollmentNo = '$studentenrollment'";
    $semdata2 = mysqli_query($conn, $querry2);
    $total2 = mysqli_num_rows($semdata2);

    //echo $total;
    if ($total1 == 1 && $total2 == 1) 
    {

        $table4 = "UPDATE studentdetails SET Semester = '$semester', Academic = '$academicsession', Bus ='$bus' WHERE EnrollmentNo='$studentenrollment'";

        $data4 = mysqli_query($conn, $table4);

        $table2 = "INSERT INTO semesterdetails (EnrollmentNo, StudentName, SemesterNo, Result, SGPA, Backlogs) VALUE ('$studentenrollment', '$studentname','$semesterD', '$semResult','$semSGPA', '$backlogSubject')";

        $data2 = mysqli_query($conn, $table2);
    } 
    elseif ($total1 == 0 && $total2 == 0) 
    {
        $table1 = "INSERT INTO studentdetails (StudentImage, EnrollmentNo, StudentName, CollegeName, CourseName, Branch, Semester, Academic, Bus, DateOfBirth, AdmissionUnder, Category, Phoneno, Aadharno, Mailid, FatherName, FatherPhoneNo, Residency, Living, Locality, City, HomeState, Pincode, LocalAddress, GuardianName, GuardianContactNo) VALUES('$filename','$studentenrollment', '$studentname', '$collegename', '$coursename', '$branch', '$semester', '$academicsession','$bus','$dateofbirth', '$admissionunder','$category', '$phoneno', '$aadharno', '$mailid', '$fathername', '$fathercontactno', '$residency', '$studentliving', '$locality','$city','$state','$pincode', '$localaddress', '$guardianname', '$guardiancontactno')";

        $data1 = mysqli_query($conn, $table1);

        $table2 = "INSERT INTO semesterdetails (EnrollmentNo, StudentName, SemesterNo, Result, SGPA, Backlogs) VALUE ('$studentenrollment', '$studentname','$semesterD', '$semResult','$semSGPA', '$backlogSubject')";

        $data2 = mysqli_query($conn, $table2);
    }
    


    if ($data2 == 1 && $data4 == 1) {
        echo '<script>alert("Submition Successful")</script>';
?>
        <meta http-equiv="refresh" content="2; url = loginpage.php" />
    <?php
    } elseif ($data1 == 1 && $data2 == 1) {
        echo '<script>alert("Submition Successful")</script>';
    ?>
        <meta http-equiv="refresh" content="0; url = loginpage.php" />
<?php
    } else {
        echo '<script>alert("Submition Failed")</script>';
    }
}


?>